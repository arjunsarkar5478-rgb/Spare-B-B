package sparebnb;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public abstract class Accommodation implements Bookable {

    private int id;
    private String title;
    protected String location;
    private double pricePerNight;
    protected int maxGuests;
    private AccommodationStatus status;

    protected User postedBy; // Protected for child access
    private List<Facility> facilities;

    public Accommodation(int id, String title, String location, double pricePerNight, int maxGuests, User host) {
        this.id = id;
        this.title = title;
        this.location = location;
        this.pricePerNight = pricePerNight;
        this.maxGuests = maxGuests;
        this.postedBy = host;
        this.facilities = new ArrayList<>();
        this.status = AccommodationStatus.AVAILABLE;
    }

    // --- INTERFACE METHOD IMPLEMENTATIONS ---
    @Override
    public double getDailyPrice() {
        return pricePerNight;
    }

    @Override
    public boolean isAvailable(LocalDate checkInDate, LocalDate checkOutDate) {
        // Simple implementation for Sprint 1
        return this.status == AccommodationStatus.AVAILABLE;
    }

    @Override
    public void book(LocalDate checkInDate, LocalDate checkOutDate) {
        // Simple implementation for Sprint 1
        this.status = AccommodationStatus.BOOKED;
    }

    // --- STANDARD METHODS ---

    public double getPricePerNight() {
        return pricePerNight;
    }

    public String getTitle() {
        return title;
    }

    public AccommodationStatus getStatus() {
        return status;
    }

    public void setStatus(AccommodationStatus newStatus) {
        this.status = newStatus;
    }

    public void addFacility(Facility facility) {
        this.facilities.add(facility);
    }

    protected String getFacilityList() {
        StringBuilder sb = new StringBuilder();
        for (Facility f : facilities) {
            sb.append(f.getInfo()).append(", ");
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - 2) : "None";
    }

    public abstract double calculateTotal(int numberOfNights);
    public abstract String printDetails();
}