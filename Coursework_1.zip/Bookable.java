package sparebnb;

import java.time.LocalDate;

public interface Bookable {

    boolean isAvailable(LocalDate checkInDate, LocalDate checkOutDate);

    void book(LocalDate checkInDate, LocalDate checkOutDate);

    double getDailyPrice();
}